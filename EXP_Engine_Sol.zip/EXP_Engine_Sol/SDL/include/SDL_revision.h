/* #undef SDL_REVISION */
#define SDL_REVISION_NUMBER 0

#ifndef SDL_REVISION
#define SDL_REVISION ""
#endif
